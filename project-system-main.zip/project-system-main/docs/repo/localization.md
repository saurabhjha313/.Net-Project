# Localization

General information about localization: https://aka.ms/AllAboutLoc

## Translation updates

We receive PRs from the localization team. When we identify issues in those PRs, we must submit feedback via https://aka.ms/ceLocBug.

Fixes typically flow back into this repository within 72 hours.
