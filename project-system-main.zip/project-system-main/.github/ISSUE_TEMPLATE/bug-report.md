---
name: Bug report
about: Report an issue with the .NET Project System for Visual Studio
title: 
labels: 
assignees: ''

---

## Visual Studio Version



## Summary



## Steps to Reproduce

1. 
2. 
3. 

## Expected Behavior



## Actual Behavior



## User Impact


