---
name: Feature request
about: Request a new feature of .NET Project System for Visual Studio
title: 
labels: 
assignees: ''

---

## Summary



## User Impact


